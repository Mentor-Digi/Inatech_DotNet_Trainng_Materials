using System;
class Meth3
{
//instance Variable
//Object is called Instance
int n1;//local variable
int n2;

public void Calc(int n1, int n2)
{
//initializing the class variable with the parameter
this.n2 = n2;//this refers to the current class
Console.WriteLine(n1+n2);
}

public void Mul()
{
Console.WriteLine(n1*n1);
}


public void Add2Numbers( int num1, int num2)
{
int res;
res = num1+num2;
Console.WriteLine(res);
}

public static void Main()
{
Meth3 obj = new Meth3();
obj.Add2Numbers(22,44);//Method call or Invoke
obj.Add2Numbers(45,60);
obj.Add2Numbers(98,58);
obj.n1 =5;
obj.Mul();
Console.WriteLine(obj.n1);
obj.Calc(obj.n1,23345);

Meth3 obj2 = new Meth3();
obj2.Add2Numbers(56,76);
obj2.n1 = 6;
Console.WriteLine(obj2.n1);
obj2.Mul();

Meth3 obj3 = new Meth3();
obj3.Add2Numbers(87,98);
}
}