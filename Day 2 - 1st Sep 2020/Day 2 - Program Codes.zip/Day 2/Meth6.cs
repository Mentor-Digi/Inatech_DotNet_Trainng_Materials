using System;
class Meth6
{
//return type is datatype of resultant value
public double add(int num1, double num2)
{
double res;
res = num1+num2;
return res;
}

public static void Main()
{
Meth6 obj = new Meth6();
double r = obj.add(44,55);
Console.WriteLine(r/2);
}
}