//Jagged Arrays
//Arrays of different size
using System;
class PatientQueue
{
//Dr1 -x
//Dr2 -y
//Dr3 -z
public static void Main()
{
String[][] pat = new String[3][];

pat[0] = new String[5]{"Sky","Buy","Cry","Fry","Dry"};
pat[1] = new String[2] {"Pan","Man"};
pat[2] = new String[3] {"Tat","Pat","Bat"};

for(int i=0;i<pat.Length;i++)
{
	for(int j =0;j<pat[i].Length; j++)
	{
	Console.Write(pat[i][j] + " ");
	}
	Console.WriteLine();
}
}
}