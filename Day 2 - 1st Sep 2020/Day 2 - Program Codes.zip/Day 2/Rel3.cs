using System;
class Father
{
public void Wealth()
{
Console.WriteLine("I have a property in ECR");
}
}
//inherit
class Son:Father
{
public void Health()
{
Console.WriteLine("I have perfect health");
}
}
class GrandChild:Son
{
new public void Health()
{
Console.WriteLine("I have Okay health");
}
}
class Imple
{
public static void Main()
{
Console.WriteLine("Father class");
Father fobj  = new Son();//Casting- Base using derived
fobj.Wealth();
//fobj.Health();
Son sobj = new Son();
GrandChild gobj = new GrandChild();
gobj.Health();
sobj.Health();
}
}