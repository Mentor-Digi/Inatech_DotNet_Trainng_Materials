using System;
class Meth3
{
public void Add2Numbers( int num1, int num2)
{
int res;
res = num1+num2;
Console.WriteLine(res);
}

public static void Main()
{
Meth3 obj = new Meth3();
obj.Add2Numbers(22,44);//Method call or Invoke
obj.Add2Numbers(45,60);
obj.Add2Numbers(98,58);

Meth3 obj2 = new Meth3();
obj2.Add2Numbers(56,76);

Meth3 obj3 = new Meth3();
obj3.Add2Numbers(87,98);
}
}