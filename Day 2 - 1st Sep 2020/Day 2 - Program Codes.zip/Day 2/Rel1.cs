using System;
class Independ
{
public void Display()
{
Console.WriteLine("Method in a class");
}
}

class Pvt
{
public void PvtMethod()
{
Independ obj = new Independ();
obj.Display();
}
public static void Main()
{
Pvt pobj = new Pvt();
pobj.PvtMethod();
}
}