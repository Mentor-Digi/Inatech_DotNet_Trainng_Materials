using System;
class Meth8
{
//Value Type and Ref Type
public static void ValSqu(int val)
{
val *= val;
Console.WriteLine(val);
}

public static void RefSqu(ref int val)
{
val *= val;
Console.WriteLine(val);
}


public static void Main()
{
int v = 4;
ValSqu(v);
ValSqu(v);
ValSqu(v);
ValSqu(v);
RefSqu(ref v);
RefSqu(ref v);
RefSqu(ref v);
RefSqu(ref v);
}
}