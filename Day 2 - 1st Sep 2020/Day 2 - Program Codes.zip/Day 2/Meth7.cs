using System;
class Meth7
{
//Out Parameter - store output
//out parameter - last parameter
//invoke - keyword out
public void add(int num1, int num2, out int res)
{
//int res;
res = num1+num2;
}
public static void Main()
{
Meth7 obj = new Meth7();
Console.WriteLine("Enter 2 values");
int n1 = Convert.ToInt32(Console.ReadLine());
int n2 = Convert.ToInt32(Console.ReadLine());
int res;
obj.add(n1,n2, out res);
Console.WriteLine(res);
}
}