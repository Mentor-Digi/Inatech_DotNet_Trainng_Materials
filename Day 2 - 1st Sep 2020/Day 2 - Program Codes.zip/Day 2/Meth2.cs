using System;
class Meth2
{
public void Add2Numbers()
{
int num1, num2;
num1  = 45; num2=67;
int res;
res = num1+num2;
Console.WriteLine(res);
}

public static void Main()
{
Meth2 obj = new Meth2();
obj.Add2Numbers();

Meth2 obj2 = new Meth2();
obj2.Add2Numbers();

Meth2 obj3 = new Meth2();
obj3.Add2Numbers();
}
}