using System;
class Father
{
public void Wealth()
{
Console.WriteLine("I have a property in ECR");
}
}
//inherit
class Son:Father
{
public void Health()
{
Console.WriteLine("I have perfect health");
}
}
class GrandChild:Son
{}
class Imple
{
public static void Main()
{
Console.WriteLine("Father class");
Father fobj = new Father();
fobj.Wealth();
Console.WriteLine("Son Class");
Son sobj = new Son();
sobj.Wealth();
sobj.Health();
Console.WriteLine("Granchild");
GrandChild gobj = new GrandChild();
gobj.Wealth();
gobj.Health();
}
}