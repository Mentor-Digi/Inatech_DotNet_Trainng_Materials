using System;
class Meth8
{
static int  x;
public static void Show()
{
Console.WriteLine("Static method");
}

public static void Main()
{
Meth8 obj = new Meth8();
x = 45;
Console.WriteLine(x);
Show();
}
}