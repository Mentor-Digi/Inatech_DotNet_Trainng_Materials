using System;
class Meth1
{
//accessSpecifier - ReturnType - Name(){}
public void Display()
{
Console.WriteLine("This is my First Method");
}

public static void Main()
{
//Class object = new class();
Meth1 obj = new Meth1(); //Memory 
obj.Display();
obj.Display();
obj.Display();
}
}