using System;
class Poly1
{
public void add()
{
int n1=45;
int n2=67;
Console.WriteLine(n1+n2);
}

public int add()
{
int n1=45;
int n2=67;
Console.WriteLine(n1+n2);
return (n1+n2);
}
public void add(int n1, int n2)
{
Console.WriteLine(n1+n2);
}

public void add(int n1, double n2)
{
Console.WriteLine(n1+n2);
}

public void add(double n2, int n1)
{
Console.WriteLine(n1+n2);
}
public static void Main()
{
Poly1 obj = new Poly1();
obj.add();
obj.add(34,78);
obj.add(56, 7.89);
obj.add(78.89, 345);
obj.add();
}
}