﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace FWClasses
{
    class Seri1
    {
        public static void Main()
        {
            FileStream fs = new FileStream("D:\\Inatech2020\\Seer1.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs,"This is my serialized data");
            fs.Close();
            FileStream fs1 = new FileStream("D:\\Inatech2020\\Seer1.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            String str = formatter.Deserialize(fs1).ToString();
            Console.WriteLine(str);
            fs1.Close();


            Console.ReadLine();
        }
    }
}
