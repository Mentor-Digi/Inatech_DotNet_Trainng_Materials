﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace FWClasses
{
    class CollGen
    {
        public static void Main()
        {
            List<String> list = new List<string>();
            list.Add("Malvika");
            list.Add("Anurag");
            list.Add("Nim");
            list.Add("Celeste");
            list.Add("2323");
            foreach (String s in list)
                Console.WriteLine(s);

            Console.ReadLine();
        }
    }
}
