﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace FWClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add("One");
            al.Add(2);
            al.Add("Three");
            al.Add(4);
            Console.WriteLine(al.Count);
            Console.WriteLine(al.Capacity);
            for (int i = 0; i < al.Count; i++)
                Console.WriteLine(al[i].ToString());
            //Enhanced FOr Loop
            foreach (Object ob in al)
                Console.WriteLine(ob.ToString());
            ArrayList list = new ArrayList();
            list.Add(45);
            list.Add(56);
            list.Add(76);
            list.Add(34);
            list.Add(53);
            foreach (int i in list)
                Console.WriteLine(i);
            list.Sort();
            Console.WriteLine("Sorted list of values");
            foreach (int i in list)
                Console.WriteLine(i);
            Console.WriteLine("Adding one collection into another");
            al.AddRange(list);
            al.Insert(3, "Good Going");
            foreach (Object o in al)
                Console.WriteLine(o.ToString());
           
            Console.ReadLine();
        }
    }
}
