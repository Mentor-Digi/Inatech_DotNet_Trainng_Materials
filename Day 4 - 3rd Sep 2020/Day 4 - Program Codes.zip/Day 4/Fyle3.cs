﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FWClasses
{
    class Fyle3
    {
        public static void Main()
        {
            FileInfo fi = new FileInfo(@"D:\Inatech2020\Myfile1.txt");
            if (fi.Exists)
            {
                Console.WriteLine(fi.FullName);
                Console.WriteLine(fi.Length);
                Console.WriteLine(fi.Extension);
                Console.WriteLine(fi.DirectoryName);
                Console.WriteLine(fi.CreationTime);
            }
            FileInfo file = new FileInfo("D:\\Inatech2020\\NewFile.txt");
            file.Create();
            Console.WriteLine("Created");

            DirectoryInfo directory = new DirectoryInfo("D:\\Inatech2020");
            Console.WriteLine(directory.CreationTime);
            Console.WriteLine(directory.LastAccessTime);
            Console.WriteLine(directory.Parent);

            foreach (Object dir in directory.GetDirectories())
                Console.WriteLine(dir);
            Console.ReadLine();
            foreach (Object f in directory.GetFiles())
                Console.WriteLine(f);
            Console.ReadLine();
            //DriveInfo dinfo = new DriveInfo("C");
            //Console.WriteLine(fi.Exists)
        }
    }
}
