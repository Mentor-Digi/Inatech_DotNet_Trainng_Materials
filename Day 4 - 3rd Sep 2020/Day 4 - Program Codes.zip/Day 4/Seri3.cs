﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace FWClasses
{
    [Serializable]
    class Seri3
    {
        public String Sname;
        public int Sage;
        public static void Main()
        {
            Seri3 obj = new Seri3();
            obj.Sname = "Vishnu Karthik";
            obj.Sage = 25;
            FileStream fs = new FileStream("D:\\Inatech2020\\Seer2.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, obj);
            fs.Close();

            FileStream fs1 = new FileStream("D:\\Inatech2020\\Seer2.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter bf1 = new BinaryFormatter();
            Seri3 obj2  = (Seri3) bf1.Deserialize(fs1);
            Console.WriteLine(obj2.Sname);
            Console.WriteLine(obj2.Sage);

            Console.ReadLine();
        }
    }
}
