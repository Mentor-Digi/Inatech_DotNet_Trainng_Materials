﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace FWClasses
{
    class Hashtb
    {
        public static void Main()
        {
            Hashtable ht = new Hashtable();
            ht.Add("001", "Becoming Michelle");
            ht.Add("002", "Deception Point");
            ht.Add("003", "Vision INdia 2020");
            ht.Add("004", "Swami and Friends");
            Console.WriteLine(ht.Contains("007"));
            //Key is available or not
            Console.WriteLine(ht.ContainsValue("Swami and Friends"));
            ht.Add("005", "The Client");
         //ht.Add(006, "The Angel");
            foreach (string s in ht.Values)
                Console.WriteLine(s);

            //foreach (object s in ht.Keys)
            //    Console.WriteLine(s + " " + ht[s]);

            foreach (string s in ht.Keys)
                Console.WriteLine(s + " " + ht[s]);



            //foreach (object s in ht.Keys)
            //    Console.WriteLine(s + " " + ht[s]);

            Console.ReadLine();
        }
    }
}
