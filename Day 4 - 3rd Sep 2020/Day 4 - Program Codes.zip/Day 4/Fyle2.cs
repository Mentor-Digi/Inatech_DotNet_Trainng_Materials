﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FWClasses
{
    class Fyle2
    {
        public static void Main()
        {
            FileStream fs = new FileStream("MyFile3.pdf", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine("John Grishm is my favourite author");
            sw.Flush();
            sw.Close();
            fs.Close();
            FileStream fs1 = new FileStream("MyFile3.pdf", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            StreamReader sr = new StreamReader(fs1);
            sr.BaseStream.Seek(0, SeekOrigin.Begin);
            Console.WriteLine(sr.ReadToEnd());
            sr.Close();
            fs1.Close();

            Console.ReadLine();
        }
    }
}
