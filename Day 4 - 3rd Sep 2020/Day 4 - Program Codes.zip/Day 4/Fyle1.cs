﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FWClasses
{
    class Fyle1
    {
        public static void Main()
        {
            FileStream fs = new FileStream("D:\\Inatech2020\\MyFile1.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write("Super Star");
            bw.Flush();
            bw.Close();
            fs.Close();

            BinaryReader br = new BinaryReader(File.Open("D:\\Inatech2020\\MyFile1.txt", FileMode.Open,FileAccess.Read));
            Console.WriteLine(br.ReadString());
            br.Close();

            Console.ReadLine();
        }
    }
}
