﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace FWClasses
{
    class Quuu
    {
        public static void Main()
        {
            Queue q = new Queue();
            q.Enqueue("A");
            q.Enqueue("B");
            q.Enqueue("C");
            //foreach (String s in q)
                String s = q.Dequeue().ToString();
            Console.WriteLine(s);
            q.Dequeue();
            Console.ReadLine();
                    


        }
    }
}
