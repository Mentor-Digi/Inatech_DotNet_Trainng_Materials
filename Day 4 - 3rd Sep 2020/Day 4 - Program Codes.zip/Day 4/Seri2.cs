﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;
using System.Xml;

namespace FWClasses
{
    class Seri2
    {
        public static void Main()
        {
            FileStream fs = new FileStream("D:\\Inatech2020\\data.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer serializer = new XmlSerializer(typeof(XmlElement));
            XmlElement element = new XmlDocument().CreateElement("Prodata");
            element.InnerText = "Biscuit";
            TextWriter tw = new StreamWriter(fs);
            serializer.Serialize(tw, element);
            tw.Close();
            fs.Close();
        }
    }
}
