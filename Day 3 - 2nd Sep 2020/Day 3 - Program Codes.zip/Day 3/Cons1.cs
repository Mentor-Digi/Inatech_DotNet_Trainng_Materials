//Constructor - Base and Derived
using System;
class Parent
{
public Parent()
{
Console.WriteLine("Parent Class Constructor Invoked");
}
}
class Child:Parent
{
public Child()
{
Console.WriteLine("Child Class Constructor Invoked");
}
}
class outSider
{
public static void Main()
{
Parent pobj = new Parent();
Console.WriteLine("Creating Child class object");
Child cobj = new Child();
}
}