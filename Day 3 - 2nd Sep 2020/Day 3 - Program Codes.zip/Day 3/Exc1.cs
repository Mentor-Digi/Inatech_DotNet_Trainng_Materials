﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Exc1
    {
        public static void Main()
        {

            int x, y, z;
            x = 45; y = 0;z = 0;
            try
            {
                z = x / y;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
              
            }
            Console.WriteLine(z);

            Console.ReadLine();

        }
    }
}
