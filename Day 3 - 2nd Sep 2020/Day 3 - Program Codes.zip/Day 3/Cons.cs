using System;
class Cons
{
int x;
int age;
string name;
public Cons()//default constructor
{
Console.WriteLine("Constructor Invoked");
//Initialize variable
x =25;
}
//Constructor Overloading
public Cons(string name, int age)
{
Console.WriteLine("Parameterized COnstructor Invoked");
this.name=  name;
this.age = age;
}
public static void Main()
{
Cons obj  = new Cons();
Cons obj1 = new Cons();
Cons obj2 = new Cons();
Console.WriteLine(obj.x);
Console.WriteLine(obj2.x);
Cons pobj = new Cons("Nim" , 16);
Console.WriteLine("Thanks for registering! YOur name is {0} and age is{1}",pobj.name, pobj.age);
Console.WriteLine(pobj.x);

Cons pobj2 = new Cons("Anurag",21);
Console.WriteLine("Thanks for registering! YOur name is {0} and age is{1}",pobj2.name, pobj2.age);

}
}