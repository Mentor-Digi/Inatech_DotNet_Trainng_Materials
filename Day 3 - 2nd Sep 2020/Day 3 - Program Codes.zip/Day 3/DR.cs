using System;
interface iFood
{
void Diet();
void Timing();
}
interface iRoutine
{
void wakeUP();
}
class Diabetes : iFood, iRoutine
{
public void Diet()
{
Console.WriteLine("Fibre rich food");
}
public void wakeUP()
{
Console.WriteLine("Wake up at 6:30");
}
public void Timing(){}
}
class Obessity:iFood
{
public void Diet()
{
Console.WriteLine("No fat, cheese, junks");
}
public void Timing(){}
}
class DR
{
public static void Main()
{
Diabetes obj = new Diabetes();
}
}