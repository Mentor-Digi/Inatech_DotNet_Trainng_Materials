﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class MajorAgeException : Exception
    {
        public MajorAgeException(String messge) : base(messge) { }
    }
    class Exc2
    {
        public static void ValidMajor(int age)
        {
            if (age < 18)
                throw new MajorAgeException("You should be 18 to be employed");
         }
        public static void Main()
        {
            try
            {
                ValidMajor(12);
            }
            catch (MajorAgeException ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            Console.ReadLine();
        }
    }
}
