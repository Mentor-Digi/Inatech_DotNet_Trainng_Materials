//base abstract methods -declaration - definition
//derived - define abstract methods- mandatory
//Why?
//Mandatory task which works differently under different scenario 
using System;
abstract class AgeLimit
{
public abstract void ValidAge();
public void Display()
{
Console.WriteLine("Normal Method");
}
}
class Children:AgeLimit
{
public override void ValidAge()
{
Console.WriteLine("Children between 5 and 12 years");
}
}
class Teenager:AgeLimit
{
public override void ValidAge()
{
Console.WriteLine("Children between 13 and 19 years");
}

}
class Demo
{
public static void Main()
{
Children obj = new Children();
obj.ValidAge();
obj.Display();
}
}