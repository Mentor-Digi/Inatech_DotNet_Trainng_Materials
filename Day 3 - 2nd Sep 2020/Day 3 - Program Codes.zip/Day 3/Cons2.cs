using System;
public class Employee
{
public string Ename;
public int Eage;
public Employee(string Ename, int Eage)
{
this.Ename = Ename;
this.Eage = Eage;
}
}
public class Department:Employee
{
public string Dept;
public Department(string En, int Ea, string Dept):base(En, Ea)
{
this.Dept = Dept;
}
~Department()
{
Console.WriteLine("Destructor invoked");
}
}
class EmpDetails
{
public static void Main()
{
Department dobj = new Department("Kankeyan", 24,"CustSupport");
Console.WriteLine(dobj.Ename);
Console.WriteLine(dobj.Eage);
Console.WriteLine(dobj.Dept);
}
}

